"""
H&S Recruiting Platform — API Layer
====================================

Sits between the front end (intake form / review queue) and orchestrator.py.
This is what the two HTML prototypes should call instead of hitting the
Anthropic API directly from the browser — keeps the API key server-side,
which matters as soon as this is hosted anywhere public.

Run:
    pip install fastapi uvicorn psycopg2-binary anthropic
    uvicorn api:app --reload

Environment:
    DATABASE_URL, ANTHROPIC_API_KEY  (same as orchestrator.py)
"""

import os
import uuid
from typing import Optional, List

from fastapi import FastAPI, HTTPException, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import psycopg2
import psycopg2.extras

import orchestrator  # the file built in the previous step

app = FastAPI(title="H&S Recruiting Pipeline API")

# Loosen for local dev; restrict to your actual front-end origin before deploying.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

DB_URL = os.environ["DATABASE_URL"]


def get_conn():
    return psycopg2.connect(DB_URL, cursor_factory=psycopg2.extras.RealDictCursor)


# ---------------------------------------------------------------------------
# Request/response models
# ---------------------------------------------------------------------------

class EmployerIn(BaseModel):
    name: str
    sector: Optional[str] = None


class RoleIn(BaseModel):
    employer_id: str
    title: str
    sector: str
    required_quals: List[str] = []
    min_experience_yrs: int = 0


class ApplicationIn(BaseModel):
    role_id: str
    candidate_name: str
    candidate_email: Optional[str] = None
    raw_cv_text: str
    consent_given: bool


class DecisionIn(BaseModel):
    reviewer_name: str
    decision: str  # "shortlist" / "reject" / "request_more_info"
    notes: str = ""


# ---------------------------------------------------------------------------
# Employers
# ---------------------------------------------------------------------------

@app.post("/employers")
def create_employer(employer: EmployerIn):
    conn = get_conn()
    try:
        with conn.cursor() as cur:
            cur.execute(
                "INSERT INTO employers (name, sector) VALUES (%s, %s) RETURNING id",
                (employer.name, employer.sector),
            )
            employer_id = cur.fetchone()["id"]
        conn.commit()
        return {"id": employer_id}
    finally:
        conn.close()


@app.get("/employers")
def list_employers():
    conn = get_conn()
    try:
        with conn.cursor() as cur:
            cur.execute("SELECT * FROM employers ORDER BY created_at DESC")
            return cur.fetchall()
    finally:
        conn.close()


@app.get("/employers/{employer_id}")
def get_employer(employer_id: str):
    conn = get_conn()
    try:
        with conn.cursor() as cur:
            cur.execute("SELECT * FROM employers WHERE id = %s", (employer_id,))
            row = cur.fetchone()
            if not row:
                raise HTTPException(status_code=404, detail="Employer not found")
            return row
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Roles
# ---------------------------------------------------------------------------

@app.post("/roles")
def create_role(role: RoleIn):
    conn = get_conn()
    try:
        with conn.cursor() as cur:
            cur.execute(
                """INSERT INTO roles (employer_id, title, sector, required_quals, min_experience_yrs, status)
                   VALUES (%s, %s, %s, %s, %s, 'open') RETURNING id""",
                (role.employer_id, role.title, role.sector, psycopg2.extras.Json(role.required_quals),
                 role.min_experience_yrs),
            )
            role_id = cur.fetchone()["id"]
        conn.commit()
        return {"id": role_id}
    finally:
        conn.close()


@app.get("/roles")
def list_roles():
    conn = get_conn()
    try:
        with conn.cursor() as cur:
            cur.execute("SELECT * FROM roles WHERE status = 'open' ORDER BY created_at DESC")
            return cur.fetchall()
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Applications — this is what the intake form calls
# ---------------------------------------------------------------------------

@app.post("/applications")
def create_application(app_in: ApplicationIn, background_tasks: BackgroundTasks):
    if not app_in.consent_given:
        raise HTTPException(status_code=400, detail="Candidate consent is required before submission.")

    conn = get_conn()
    try:
        with conn.cursor() as cur:
            cur.execute(
                """INSERT INTO candidates (name, email, raw_cv_text, consent_ai_processing_at)
                   VALUES (%s, %s, %s, now()) RETURNING id""",
                (app_in.candidate_name, app_in.candidate_email, app_in.raw_cv_text),
            )
            candidate_id = cur.fetchone()["id"]

            cur.execute(
                """INSERT INTO applications (candidate_id, role_id, status)
                   VALUES (%s, %s, 'new') RETURNING id""",
                (candidate_id, app_in.role_id),
            )
            application_id = cur.fetchone()["id"]
        conn.commit()
    finally:
        conn.close()

    # Run the pipeline asynchronously so the intake form gets an instant response
    # and can poll /applications/{id} for progress rather than blocking on it.
    background_tasks.add_task(orchestrator.run_pipeline_for_application, application_id)

    return {"id": application_id, "status": "new", "message": "Pipeline started."}


@app.get("/applications/{application_id}")
def get_application(application_id: str):
    conn = get_conn()
    try:
        with conn.cursor() as cur:
            cur.execute(
                """SELECT a.*, c.name as candidate_name, r.title as role_title
                   FROM applications a
                   JOIN candidates c ON c.id = a.candidate_id
                   JOIN roles r ON r.id = a.role_id
                   WHERE a.id = %s""",
                (application_id,),
            )
            app_row = cur.fetchone()
            if not app_row:
                raise HTTPException(status_code=404, detail="Application not found")

            cur.execute(
                """SELECT agent_type, status, output, error, started_at, completed_at
                   FROM agent_runs WHERE application_id = %s ORDER BY started_at""",
                (application_id,),
            )
            agent_trail = cur.fetchall()

            cur.execute(
                "SELECT flag_type, description, severity FROM compliance_flags WHERE application_id = %s",
                (application_id,),
            )
            flags = cur.fetchall()

        return {"application": app_row, "agent_trail": agent_trail, "compliance_flags": flags}
    finally:
        conn.close()


@app.get("/applications")
def list_applications(status: Optional[str] = None):
    """Used by the review queue. Pass status=pending_human_review to get the reviewer's queue."""
    conn = get_conn()
    try:
        with conn.cursor() as cur:
            if status:
                cur.execute(
                    """SELECT a.*, c.name as candidate_name, r.title as role_title
                       FROM applications a
                       JOIN candidates c ON c.id = a.candidate_id
                       JOIN roles r ON r.id = a.role_id
                       WHERE a.status = %s ORDER BY a.updated_at DESC""",
                    (status,),
                )
            else:
                cur.execute(
                    """SELECT a.*, c.name as candidate_name, r.title as role_title
                       FROM applications a
                       JOIN candidates c ON c.id = a.candidate_id
                       JOIN roles r ON r.id = a.role_id
                       ORDER BY a.updated_at DESC"""
                )
            return cur.fetchall()
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Human decision — this is what the review screen's Shortlist/Reject buttons call
# ---------------------------------------------------------------------------

@app.post("/applications/{application_id}/decision")
def submit_decision(application_id: str, decision_in: DecisionIn):
    if decision_in.decision not in ("shortlist", "reject", "request_more_info"):
        raise HTTPException(status_code=400, detail="Invalid decision value.")
    try:
        orchestrator.record_human_decision(
            application_id=application_id,
            reviewer_name=decision_in.reviewer_name,
            decision=decision_in.decision,
            notes=decision_in.notes,
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    return {"application_id": application_id, "decision": decision_in.decision}


@app.get("/health")
def health():
    return {"status": "ok"}
